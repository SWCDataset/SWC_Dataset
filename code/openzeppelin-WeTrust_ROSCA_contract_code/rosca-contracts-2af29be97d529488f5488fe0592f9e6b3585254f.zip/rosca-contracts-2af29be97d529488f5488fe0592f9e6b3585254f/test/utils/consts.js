"use strict";

// TODO(ron): move the different ROSCA constants here.
module.exports = {
  MAX_GAS_COST_PER_TX: 1e5 /* gas used per tx */ * 2e10, /* gas price */  // keep in sync with truffle.js
};
