export abstract class AbstractAssetWrapper {
    public abstract getProxyId(): string;
}
