<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.2.0-beta.0 - _October 3, 2019_

    * Add `mintKnownFungibleTokensAsync()`, `isNonFungibleItemAsync()`, `isFungibleItemAsync()`, `getOwnerOfAsync()`, `getBalanceAsync()` to `Erc1155Wrapper`. (#1819)

## v1.1.15 - _September 17, 2019_

    * Dependencies updated

## v1.1.14 - _September 3, 2019_

    * Dependencies updated

## v1.1.13 - _August 22, 2019_

    * Dependencies updated

## v1.1.12 - _August 8, 2019_

    * Dependencies updated

## v1.1.11 - _July 31, 2019_

    * Updated calls to <contract wrapper>.deployFrom0xArtifactAsync to include artifact dependencies. (#1995)

## v1.1.10 - _July 24, 2019_

    * Dependencies updated

## v1.1.9 - _July 15, 2019_

    * Dependencies updated

## v1.1.8 - _July 13, 2019_

    * Dependencies updated

## v1.1.7 - _July 13, 2019_

    * Dependencies updated

## v1.1.6 - _May 24, 2019_

    * Dependencies updated

## v1.1.5 - _May 15, 2019_

    * Dependencies updated

## v1.1.4 - _May 14, 2019_

    * Dependencies updated

## v1.1.2 - _May 10, 2019_

    * Dependencies updated

## v1.1.1 - _April 11, 2019_

    * Dependencies updated

## v1.1.0 - _March 21, 2019_

    * Run Web3ProviderEngine without excess block polling (#1695)

## v1.0.1 - _March 20, 2019_

    * Dependencies updated

## v1.0.0 - _Invalid date_

    * Created ERC1155 contracts package (#1657)
