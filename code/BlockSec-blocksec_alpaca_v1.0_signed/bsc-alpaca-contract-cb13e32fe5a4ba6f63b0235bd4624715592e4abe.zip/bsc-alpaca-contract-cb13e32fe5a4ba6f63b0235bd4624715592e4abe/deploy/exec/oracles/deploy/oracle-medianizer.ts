import { HardhatRuntimeEnvironment } from 'hardhat/types';
import { DeployFunction } from 'hardhat-deploy/types';
import { ethers, upgrades } from 'hardhat';
import { OracleMedianizer__factory } from '../../../../typechain';

const func: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  /*
  ░██╗░░░░░░░██╗░█████╗░██████╗░███╗░░██╗██╗███╗░░██╗░██████╗░
  ░██║░░██╗░░██║██╔══██╗██╔══██╗████╗░██║██║████╗░██║██╔════╝░
  ░╚██╗████╗██╔╝███████║██████╔╝██╔██╗██║██║██╔██╗██║██║░░██╗░
  ░░████╔═████║░██╔══██║██╔══██╗██║╚████║██║██║╚████║██║░░╚██╗
  ░░╚██╔╝░╚██╔╝░██║░░██║██║░░██║██║░╚███║██║██║░╚███║╚██████╔╝
  ░░░╚═╝░░░╚═╝░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚═╝╚═╝░░╚══╝░╚═════╝░
  Check all variables below before execute the deployment script
  */















  console.log(">> Deploying an upgradable OracleMedianizer contract");
  const OracleMedianizer = (await ethers.getContractFactory(
    'OracleMedianizer',
    (await ethers.getSigners())[0]
  )) as OracleMedianizer__factory;
  const oracleMedianizer = await upgrades.deployProxy(
    OracleMedianizer
  );
  await oracleMedianizer._deployed();
  console.log(`>> Deployed at ${oracleMedianizer.address}`);
};

export default func;
func.tags = ['OracleMedianizer'];