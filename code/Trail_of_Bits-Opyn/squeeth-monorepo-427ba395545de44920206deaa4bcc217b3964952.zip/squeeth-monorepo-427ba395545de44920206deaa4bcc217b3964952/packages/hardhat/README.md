# Squeeth Contracts

## Available scripts

### Compile

```shell
yarn compile
```

### Test

run test with hardhat network

```shell
yarn test
```

### Coverage report

```shell
yarn coverage
```

### Deploy

Need to have localhost network started

```shell
yarn deploy
```

### Lint

```shell
```