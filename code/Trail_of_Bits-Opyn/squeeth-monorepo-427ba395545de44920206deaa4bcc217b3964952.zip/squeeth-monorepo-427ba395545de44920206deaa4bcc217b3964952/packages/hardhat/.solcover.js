module.exports = {
  skipFiles: ['mocks/', 'packages/','interfaces/', 'external/','test/','import/']
};