# `IShortPowerPerp`

## All Functions:

- `nextId()`

- `mintNFT(address recipient)`

# Functions

## `nextId() → uint256`

## `mintNFT(address recipient) → uint256 _newId`
