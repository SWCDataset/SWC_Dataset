# `MockUniswapV3Pool`

## All Functions:

- `setPoolTokens(address _token0, address _token1)`

- `setSlot0Data(uint160 _sqrtPriceX96, int24 _tick)`

- `flash(address recipient, uint256 amount0, uint256 amount1, bytes data)`

# Functions

## `setPoolTokens(address _token0, address _token1)`

## `setSlot0Data(uint160 _sqrtPriceX96, int24 _tick)`

## `flash(address recipient, uint256 amount0, uint256 amount1, bytes data)`
