# `OracleLibrary`

provides functions to integrate with uniswap v3 oracle

## All Functions:

# Functions
