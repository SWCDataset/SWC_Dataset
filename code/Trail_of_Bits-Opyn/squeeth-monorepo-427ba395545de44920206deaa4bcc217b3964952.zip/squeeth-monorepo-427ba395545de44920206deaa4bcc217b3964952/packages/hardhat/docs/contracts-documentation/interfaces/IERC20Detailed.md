# `IERC20Detailed`

## All Functions:

- `decimals()`

# Functions

## `decimals() → uint8`
