# `MockErc20`

## All Functions:

- `constructor(string _name, string _symbol, uint8 _decimals)`

- `mint(address _account, uint256 _amount)`

- `burn(address _account, uint256 _amount)`

# Functions

## `constructor(string _name, string _symbol, uint8 _decimals)`

## `mint(address _account, uint256 _amount)`

## `burn(address _account, uint256 _amount)`
