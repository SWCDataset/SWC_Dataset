# `ControllerTester`

use this contract to confirm that funding is not charged twice if called in same block

## All Functions:

- `constructor(address _controller)`

- `testDoubleFunding()`

# Functions

## `constructor(address _controller)`

## `testDoubleFunding()`
