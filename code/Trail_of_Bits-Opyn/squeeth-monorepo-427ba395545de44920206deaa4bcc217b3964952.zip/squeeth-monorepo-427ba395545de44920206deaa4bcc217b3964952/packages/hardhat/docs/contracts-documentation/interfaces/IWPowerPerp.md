# `IWPowerPerp`

## All Functions:

- `mint(address _account, uint256 _amount)`

- `burn(address _account, uint256 _amount)`

# Functions

## `mint(address _account, uint256 _amount)`

## `burn(address _account, uint256 _amount)`
