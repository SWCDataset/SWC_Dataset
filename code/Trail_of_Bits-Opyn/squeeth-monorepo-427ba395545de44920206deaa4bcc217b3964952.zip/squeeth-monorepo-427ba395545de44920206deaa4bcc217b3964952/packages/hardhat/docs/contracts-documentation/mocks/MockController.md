# `MockController`

## All Functions:

- `init(address _shortPowerPerp, address _wPowerPerp)`

- `mintWPowerPerpAmount(uint256 _vaultId, uint128 _mintAmount, uint256)`

- `burnWPowerPerpAmount(uint256 _vaultId, uint256 _amount, uint256 _withdrawAmount)`

# Functions

## `init(address _shortPowerPerp, address _wPowerPerp)`

## `mintWPowerPerpAmount(uint256 _vaultId, uint128 _mintAmount, uint256) → uint256, uint256`

## `burnWPowerPerpAmount(uint256 _vaultId, uint256 _amount, uint256 _withdrawAmount)`
