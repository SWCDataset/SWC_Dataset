# `MockShortPowerPerp`

## All Functions:

- `mintNFT(address _recipient)`

- `burnNFT(uint256 _tokenId)`

# Functions

## `mintNFT(address _recipient) → uint256 tokenId`

## `burnNFT(uint256 _tokenId)`
