# `MockVaultNFTManager`

## Functions:

- `mintNFT(address _recipient) (external)`

- `burnNFT(uint256 _tokenId) (external)`

### Function `mintNFT(address _recipient) → uint256 tokenId external`

### Function `burnNFT(uint256 _tokenId) external`
