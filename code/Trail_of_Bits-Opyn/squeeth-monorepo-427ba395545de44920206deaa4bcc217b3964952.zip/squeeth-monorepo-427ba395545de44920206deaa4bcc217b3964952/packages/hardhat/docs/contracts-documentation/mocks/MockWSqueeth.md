# `MockWSqueeth`

## Functions:

- `mint(address _account, uint256 _amount) (external)`

- `burn(address _account, uint256 _amount) (external)`

### Function `mint(address _account, uint256 _amount) external`

### Function `burn(address _account, uint256 _amount) external`
