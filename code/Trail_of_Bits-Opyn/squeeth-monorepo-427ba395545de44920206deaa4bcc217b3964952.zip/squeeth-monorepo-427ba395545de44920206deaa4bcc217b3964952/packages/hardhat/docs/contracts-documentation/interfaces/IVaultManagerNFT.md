# `IVaultManagerNFT`

## Functions:

- `mintNFT(address recipient) (external)`

### Function `mintNFT(address recipient) → uint256 _newId external`
