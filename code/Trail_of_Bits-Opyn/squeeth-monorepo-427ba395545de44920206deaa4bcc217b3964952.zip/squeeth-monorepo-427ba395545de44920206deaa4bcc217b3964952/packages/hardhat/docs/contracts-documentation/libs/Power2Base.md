# `Power2Base`

## All Functions:

# Functions
