# `IWETH9`

## All Functions:

- `deposit()`

- `withdraw(uint256 wad)`

# Functions

## `deposit()`

## `withdraw(uint256 wad)`
