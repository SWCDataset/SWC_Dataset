# `IUniswapV3FlashCallback`

## All Functions:

- `uniswapV3FlashCallback(uint256 fee0, uint256 fee1, bytes data)`

# Functions

## `uniswapV3FlashCallback(uint256 fee0, uint256 fee1, bytes data)`
