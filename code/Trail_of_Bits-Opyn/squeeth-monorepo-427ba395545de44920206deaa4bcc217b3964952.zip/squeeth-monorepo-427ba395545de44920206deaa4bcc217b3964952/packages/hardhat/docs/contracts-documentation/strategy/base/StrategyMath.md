# `StrategyMath`

## All Functions:

# Functions
