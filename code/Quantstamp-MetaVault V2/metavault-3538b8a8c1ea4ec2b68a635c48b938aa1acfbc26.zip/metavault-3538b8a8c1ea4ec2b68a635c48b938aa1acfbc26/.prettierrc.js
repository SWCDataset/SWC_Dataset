module.exports = {
    semi: true,
    singleQuote: true,
    tabWidth: 4,
    printWidth: 95,
    endOfLine: 'auto',
    trailingComma: 'none'
};
