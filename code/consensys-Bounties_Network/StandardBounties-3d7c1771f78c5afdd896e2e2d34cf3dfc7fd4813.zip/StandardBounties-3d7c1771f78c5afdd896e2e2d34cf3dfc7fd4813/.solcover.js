module.exports = {
	skipFiles: ['inherited/']
};
