# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.2](https://github.com/UMAprotocol/protocol/compare/@uma/cli@1.0.1...@uma/cli@1.0.2) (2020-11-23)

**Note:** Version bump only for package @uma/cli

## [1.0.1](https://github.com/UMAprotocol/protocol/compare/@uma/cli@1.0.0...@uma/cli@1.0.1) (2020-10-05)

### Bug Fixes

- **cli:** fix cli startup when installed as a package ([#1994](https://github.com/UMAprotocol/protocol/issues/1994)) ([a66e482](https://github.com/UMAprotocol/protocol/commit/a66e482c2916af0435010c783c196744e804711e))

# 1.0.0 (2020-09-15)

Initial Release!
