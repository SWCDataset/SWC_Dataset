module.exports = require("@uma/common").getTruffleConfig(__dirname);
