# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.2](https://github.com/UMAprotocol/protocol/compare/@uma/reporters@1.0.1...@uma/reporters@1.0.2) (2020-11-23)

**Note:** Version bump only for package @uma/reporters

## [1.0.1](https://github.com/UMAprotocol/protocol/compare/@uma/reporters@1.0.0...@uma/reporters@1.0.1) (2020-10-05)

**Note:** Version bump only for package @uma/reporters

# 1.0.0 (2020-09-15)

Initial Release!
