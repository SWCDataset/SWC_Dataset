module.exports = {
  development: require("./development"),
  "development-fork": require("./development"),
  ropsten: require("./ropsten"),
  "ropsten-fork": require("./ropsten"),
  main: require("./mainnet"),
  "main-fork": require("./mainnet"),
};
