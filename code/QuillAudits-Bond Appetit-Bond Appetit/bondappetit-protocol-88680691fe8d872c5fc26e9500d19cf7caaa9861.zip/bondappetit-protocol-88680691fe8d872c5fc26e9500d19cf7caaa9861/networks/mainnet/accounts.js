module.exports = {
  Governor: {
    address: "0x87aa18a47EeE34F47187159Ba3431aF143a5ceA8",
    name: "Governor",
  },
};
