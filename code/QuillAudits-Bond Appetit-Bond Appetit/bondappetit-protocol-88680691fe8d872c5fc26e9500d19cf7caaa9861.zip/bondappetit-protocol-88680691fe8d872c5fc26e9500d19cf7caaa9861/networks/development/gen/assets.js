module.exports = {
    "Governance": {
        "address": "0x780086577C7A94eb907174e17D6Ef84cb223b861",
        "name": "BondAppetit Governance",
        "symbol": "BAG",
        "decimals": 18,
        "investing": false
    },
    "Stable": {
        "address": "0xb028D5a54f996bA4EF3eF2C2C7707db1f3D93120",
        "name": "Appetite USD",
        "symbol": "USDp",
        "decimals": 18,
        "investing": false
    }
}