module.exports = {
  Governor: {
    address: "0x9403932015576D13Fb26B135ed7a35d5d95C18d4",
    name: "Governor",
  },
};
