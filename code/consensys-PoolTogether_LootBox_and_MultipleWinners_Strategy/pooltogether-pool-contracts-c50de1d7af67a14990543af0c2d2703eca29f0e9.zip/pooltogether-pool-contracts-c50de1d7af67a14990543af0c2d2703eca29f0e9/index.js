const Constants = require('./js/constants')
const { deployMockModule } = require('./js/deployMockModule')

module.exports = {
  Constants,
  deployMockModule
}