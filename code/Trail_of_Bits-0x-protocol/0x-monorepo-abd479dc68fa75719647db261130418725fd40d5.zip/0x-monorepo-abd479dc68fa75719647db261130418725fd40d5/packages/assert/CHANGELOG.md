<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v2.1.3 - _August 8, 2019_

    * Dependencies updated

## v2.1.2 - _July 31, 2019_

    * Dependencies updated

## v2.1.1 - _July 24, 2019_

    * Dependencies updated

## v2.1.0 - _July 13, 2019_

    * Add new assertions: `isArray`, `isBlockParam` and `isNumberOrBigNumber` (#1823)

## v2.0.10 - _May 10, 2019_

    * Dependencies updated

## v2.0.9 - _April 11, 2019_

    * Dependencies updated

## v2.0.8 - _March 21, 2019_

    * Dependencies updated

## v2.0.7 - _March 20, 2019_

    * Dependencies updated

## v2.0.6 - _March 1, 2019_

    * Dependencies updated

## v2.0.5 - _February 26, 2019_

    * Dependencies updated

## v2.0.4 - _February 25, 2019_

    * Dependencies updated

## v2.0.3 - _February 9, 2019_

    * Dependencies updated

## v2.0.2 - _February 7, 2019_

    * Dependencies updated

## v2.0.1 - _February 6, 2019_

    * Dependencies updated

## v2.0.0 - _February 5, 2019_

    * Upgrade the bignumber.js to v8.0.2 (#1517)

## v1.0.23 - _January 15, 2019_

    * Dependencies updated

## v1.0.22 - _January 11, 2019_

    * Dependencies updated

## v1.0.21 - _January 9, 2019_

    * Dependencies updated

## v1.0.20 - _December 13, 2018_

    * Dependencies updated

## v1.0.19 - _December 11, 2018_

    * Dependencies updated

## v1.0.18 - _November 21, 2018_

    * Dependencies updated

## v1.0.17 - _November 14, 2018_

    * Dependencies updated

## v1.0.16 - _November 12, 2018_

    * Dependencies updated

## v1.0.15 - _November 9, 2018_

    * Dependencies updated

## v1.0.14 - _October 18, 2018_

    * Dependencies updated

## v1.0.13 - _October 4, 2018_

    * Dependencies updated

## v1.0.12 - _September 28, 2018_

    * Dependencies updated

## v1.0.11 - _September 25, 2018_

    * Dependencies updated

## v1.0.10 - _September 25, 2018_

    * Dependencies updated

## v1.0.9 - _September 21, 2018_

    * Dependencies updated

## v1.0.8 - _September 5, 2018_

    * Dependencies updated

## v1.0.7 - _August 27, 2018_

    * Dependencies updated

## v1.0.6 - _August 24, 2018_

    * Dependencies updated

## v1.0.5 - _August 14, 2018_

    * Dependencies updated

## v1.0.4 - _July 26, 2018_

    * Dependencies updated

## v1.0.3 - _July 26, 2018_

    * Dependencies updated

## v1.0.2 - _July 26, 2018_

    * Dependencies updated

## v1.0.1 - _July 23, 2018_

    * Dependencies updated

## v1.0.0 - _July 19, 2018_

    * Fix bug in string enum assertion. We erroneously were checking against the enum keys, not values (#821)

## v0.2.14 - _July 18, 2018_

    * Dependencies updated

## v0.2.13 - _July 9, 2018_

    * Dependencies updated

## v0.2.12 - _June 19, 2018_

    * Dependencies updated

## v0.2.11 - _May 31, 2018_

    * Incorrect publish that was unpublished

## v0.2.10 - _May 22, 2018_

    * Dependencies updated

## v0.2.9 - _May 4, 2018_

    * Dependencies updated

## v0.2.8 - _May 4, 2018_

    * Dependencies updated

## v0.2.7 - _April 18, 2018_

    * Dependencies updated

## v0.2.6 - _April 11, 2018_

    * Dependencies updated

## v0.2.5 - _April 2, 2018_

    * Dependencies updated

## v0.2.4 - _April 2, 2018_

    * Dependencies updated

## v0.2.0 - _March 7, 2018_

    * Rename `isHttpUrl` to `isWebUri` (#412)

## v0.1.0 - _March 3, 2018_

    * Remove isETHAddressHex checksum address check and assume address will be lowercased  (#373)
    * Add an optional parameter `subSchemas` to `doesConformToSchema` method (#385)

## v0.0.18 - _February 8, 2017_

    * Fix publishing issue where .npmignore was not properly excluding undesired content (#389)

## v0.0.4 - _November 13, 2017_

    * Re-publish Assert previously published under NPM package @0xproject/0x-assert
    * Added assertion isValidBaseUnitAmount which checks both that the value is a valid bigNumber and that it does not contain decimals.
