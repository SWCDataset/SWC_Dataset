<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v2.4.1 - _August 8, 2019_

    * Dependencies updated

## v2.4.0 - _July 31, 2019_

    * Updated interface to `deployFrom0xArtifactAsync` to include log decode dependencies. (#1995)
    * Updated interface to `deployAsync` to include log decode dependencies. (#1995)

## v2.3.0 - _July 24, 2019_

    * Python: fix broken event handling (#1919)
    * Python: custom validator class support (#1919)
    * Python: linter fixes (#1919)
    * Python: normalize bytes parameters in wrapper methods (#1919)

## v2.2.1 - _July 13, 2019_

    * Dependencies updated

## v2.2.0 - _July 12, 2019_

    * add parameter assertions to methods (#1823)
    * Move `getABITransactionData` to `callAsync` template (#1863)
    * Initial support for Python (#1878)

## v2.1.0 - _May 10, 2019_

    * add `awaitTransactionSuccessAsync()` to `tx.handlebars` (#1797)

## v2.0.2 - _April 11, 2019_

    * Dependencies updated

## v2.0.1 - _February 25, 2019_

    * Dependencies updated

## v2.0.0 - _February 5, 2019_

    * Upgrade the bignumber.js to v8.0.2 (#1517)

## v1.0.2 - _January 15, 2019_

    * Dependencies updated

## v1.0.1 - _November 28, 2018_

    * Dependencies updated

## v1.0.0 - _Invalid date_

    * Initial publish (#1305)
