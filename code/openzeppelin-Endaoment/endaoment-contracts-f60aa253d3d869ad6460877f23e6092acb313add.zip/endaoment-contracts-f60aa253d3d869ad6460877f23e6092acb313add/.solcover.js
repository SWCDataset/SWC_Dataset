module.exports = {
  client: require('ganache-cli'),
}
