npm run ganache > /dev/null &
truffle test --network development
