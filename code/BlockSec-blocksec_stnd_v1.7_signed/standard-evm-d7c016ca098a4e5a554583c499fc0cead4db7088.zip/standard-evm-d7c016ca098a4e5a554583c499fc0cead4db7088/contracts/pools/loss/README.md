# MasterPool

MasterPool contract is the fork of code from [MasterChef V2](https://github.com/sushiswap/sushiswap/blob/canary/contracts) with the following modifications.

1. Removing connection from MasterChef V1 and control right from the beginning
