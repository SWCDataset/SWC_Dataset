# Standard Vault

Stablecoin vault implementation

# License

The Vault code is licensed from Hyungsuk Kang and is licensed only to Standard Protocol.
