# Wrapped Metaverse Tokens

This contract directory contains standard wrapper for metaverse tokens formed in EIP 1155 standard.