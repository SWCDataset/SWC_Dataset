# Standard CLI

Commands to interact with Standard Protocol EVM implementation