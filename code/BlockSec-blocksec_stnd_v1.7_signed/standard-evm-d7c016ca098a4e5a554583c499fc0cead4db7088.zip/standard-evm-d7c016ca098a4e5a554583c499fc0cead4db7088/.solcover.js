module.exports = {
    skipFiles: ["interfaces", "examples", "flat", "mocks"],
};