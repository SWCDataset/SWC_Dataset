const {
  custodian,
  whitelistedPoaBuyers,
  defaultIpfsHash,
  setupPoaProxyAndEcosystem,
  testStartSale,
  testBuyTokens,
  determineNeededTimeTravel,
  testBuyRemainingTokens,
  testActivate,
  testBrokerClaim,
  testPayout,
  testClaimAllPayouts
} = require('../../helpers/poa')
const { timeTravel, gasPrice } = require('../../helpers/general.js')

describe("when going through Poa's normal flow", async () => {
  contract('PoaToken', () => {
    let fmr
    let poa

    before('setup contracts', async () => {
      const contracts = await setupPoaProxyAndEcosystem()
      poa = contracts.poa
      fmr = contracts.fmr
    })

    it('should move from PreFunding to Funding after startTime', async () => {
      const neededTime = await determineNeededTimeTravel(poa)
      await timeTravel(neededTime)
      await testStartSale(poa)
    })

    it('should allow buying', async () => {
      await testBuyTokens(poa, {
        from: whitelistedPoaBuyers[0],
        value: 5e17,
        gasPrice
      })
    })

    it('should buy all remaining tokens, moving to Pending', async () => {
      await testBuyRemainingTokens(poa, {
        from: whitelistedPoaBuyers[1],
        gasPrice
      })
    })

    it('should activate with ipfs hash from custodian', async () => {
      await testActivate(poa, fmr, defaultIpfsHash, {
        from: custodian
      })
    })

    it('should claim contract funding as broker', async () => {
      await testBrokerClaim(poa)
    })

    it('should payout from custodian', async () => {
      await testPayout(poa, fmr, {
        from: custodian,
        value: 2e18,
        gasPrice
      })
    })

    it('should allow all token holders to claim', async () => {
      await testClaimAllPayouts(poa, whitelistedPoaBuyers)
    })
  })
})
