**[REMOVE ME]: Please fill out as many of the below sections as possible and remove the ones that don't apply to this MR**

### Description
Provide a short description of the feature that was implemented

##### What should it look like?
Add avocado links, screenshots or animated GIFs showing the new feature in action

### Related issues
e.g. Fixes #123

### Done
* [x] List
* [x] of
* [x] done
* [x] Tasks

### Open Tasks for future MR
* [ ] List => https://git.brickblock-dev.io/group/project/issue/<issue-number>
* [ ] of => https://git.brickblock-dev.io/group/project/issue/<issue-number>
* [ ] open => https://git.brickblock-dev.io/group/project/issue/<issue-number>
* [ ] Tasks => https://git.brickblock-dev.io/group/project/issue/<issue-number>

### How to test this MR
##### Test the feature
1. Detailed Instructions
1. for reviewers
1. on how to test
1. the new feature
