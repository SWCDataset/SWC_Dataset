yarn lint
printf " ✅\n"

printf "1️⃣  Running tests…"
yarn test
printf " ✅\n"

printf "2️⃣  Searching for open TODOs and FIXMEs in the code…"
printf "6️⃣  Searching for open TODOs and FIXMEs in the code…"
yarn todo