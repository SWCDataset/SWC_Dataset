# `MockAddressBook`

## Functions:

- `setOtokenImpl(address _newImpl) (external)`

- `setWhitelist(address _newImpl) (external)`

- `setOtokenFactory(address _otokenFactory) (external)`

- `setController(address _controller) (external)`

- `setOracle(address _oracleAddr) (external)`

- `setMarginCalculator(address _calculator) (external)`

- `setMarginPool(address _pool) (external)`

- `getOtokenImpl() (external)`

- `getWhitelist() (external)`

- `getOtokenFactory() (external)`

- `getOracle() (external)`

- `getController() (external)`

- `getMarginCalculator() (external)`

- `getMarginPool() (external)`

### Function `setOtokenImpl(address _newImpl) external`

### Function `setWhitelist(address _newImpl) external`

### Function `setOtokenFactory(address _otokenFactory) external`

### Function `setController(address _controller) external`

### Function `setOracle(address _oracleAddr) external`

### Function `setMarginCalculator(address _calculator) external`

### Function `setMarginPool(address _pool) external`

### Function `getOtokenImpl() → address external`

### Function `getWhitelist() → address external`

### Function `getOtokenFactory() → address external`

### Function `getOracle() → address external`

### Function `getController() → address external`

### Function `getMarginCalculator() → address external`

### Function `getMarginPool() → address external`
