# `MockPricer`

## Functions:

- `constructor(address _asset, address _oracle) (public)`

- `setPrice(uint256 _price) (external)`

- `getPrice() (external)`

- `setExpiryPriceInOracle(uint256 _expiryTimestamp, uint256 _price) (external)`

### Function `constructor(address _asset, address _oracle) public`

### Function `setPrice(uint256 _price) external`

### Function `getPrice() → uint256 external`

### Function `setExpiryPriceInOracle(uint256 _expiryTimestamp, uint256 _price) external`
