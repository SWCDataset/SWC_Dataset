# `MockERC20`

## Functions:

- `constructor(string _name, string _symbol, uint8 _decimals) (public)`

- `mint(address account, uint256 amount) (public)`

### Function `constructor(string _name, string _symbol, uint8 _decimals) public`

### Function `mint(address account, uint256 amount) public`
