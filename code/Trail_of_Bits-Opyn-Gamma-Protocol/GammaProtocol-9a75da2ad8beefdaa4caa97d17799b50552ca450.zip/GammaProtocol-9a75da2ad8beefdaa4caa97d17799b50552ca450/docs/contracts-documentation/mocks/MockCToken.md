# `MockCToken`

## Functions:

- `constructor(string _name, string _symbol) (public)`

- `mint(address account, uint256 amount) (public)`

- `setExchangeRate(uint256 _exchangeRateStored) (external)`

### Function `constructor(string _name, string _symbol) public`

### Function `mint(address account, uint256 amount) public`

### Function `setExchangeRate(uint256 _exchangeRateStored) external`
