# `Migrations`

## Modifiers:

- `restricted()`

## Functions:

- `setCompleted(uint256 completed) (public)`

### Modifier `restricted()`

### Function `setCompleted(uint256 completed) public`
