# `MarginPoolInterface`

## Functions:

- `transferToPool(address _asset, address _user, uint256 _amount) (external)`

- `transferToUser(address _asset, address _user, uint256 _amount) (external)`

- `transferToPool(address[] _asset, address[] _user, uint256[] _amount) (external)`

- `transferToUser(address[] _asset, address[] _user, uint256[] _amount) (external)`

### Function `transferToPool(address _asset, address _user, uint256 _amount) external`

### Function `transferToUser(address _asset, address _user, uint256 _amount) external`

### Function `transferToPool(address[] _asset, address[] _user, uint256[] _amount) external`

### Function `transferToUser(address[] _asset, address[] _user, uint256[] _amount) external`
