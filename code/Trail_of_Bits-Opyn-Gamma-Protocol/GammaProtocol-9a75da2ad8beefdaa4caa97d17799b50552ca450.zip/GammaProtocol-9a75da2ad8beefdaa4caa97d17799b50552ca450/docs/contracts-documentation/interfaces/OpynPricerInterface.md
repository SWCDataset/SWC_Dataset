# `OpynPricerInterface`

## Functions:

- `getPrice() (external)`

### Function `getPrice() → uint256 external`
