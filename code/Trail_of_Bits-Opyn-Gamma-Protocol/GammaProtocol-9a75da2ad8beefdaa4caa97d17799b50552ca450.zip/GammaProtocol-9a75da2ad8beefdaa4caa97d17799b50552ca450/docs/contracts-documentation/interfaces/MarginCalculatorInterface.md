# `MarginCalculatorInterface`

## Functions:

- `getExpiredPayoutRate(address _otoken) (external)`

- `getExcessCollateral(struct MarginVault.Vault _vault) (external)`

### Function `getExpiredPayoutRate(address _otoken) → uint256 external`

### Function `getExcessCollateral(struct MarginVault.Vault _vault) → uint256 netValue, bool isExcess external`
