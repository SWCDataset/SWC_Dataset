# `Context`

## Functions:

- `_msgSender() (internal)`

- `_msgData() (internal)`

### Function `_msgSender() → address payable internal`

### Function `_msgData() → bytes internal`
