# `ContextUpgradeSafe`

## Functions:

- `__Context_init() (internal)`

- `__Context_init_unchained() (internal)`

- `_msgSender() (internal)`

- `_msgData() (internal)`

### Function `__Context_init() internal`

### Function `__Context_init_unchained() internal`

### Function `_msgSender() → address payable internal`

### Function `_msgData() → bytes internal`
