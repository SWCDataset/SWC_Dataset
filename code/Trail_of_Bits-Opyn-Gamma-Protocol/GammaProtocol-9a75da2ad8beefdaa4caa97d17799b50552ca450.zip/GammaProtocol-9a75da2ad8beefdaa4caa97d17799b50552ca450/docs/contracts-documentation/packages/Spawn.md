# `Spawn`

This contract provides creation code that is used by Spawner in order

to initialize and deploy eip-1167 minimal proxies for a given logic contract.

SPDX-License-Identifier: MIT

## Functions:

- `constructor(address logicContract, bytes initializationCalldata) (public)`

### Function `constructor(address logicContract, bytes initializationCalldata) public`
