# `BokkyPooBahsDateTimeLibrary`

## Functions:

- `_daysToDate(uint256 _days) (internal)`

- `timestampToDate(uint256 timestamp) (internal)`

### Function `_daysToDate(uint256 _days) → uint256 year, uint256 month, uint256 day internal`

### Function `timestampToDate(uint256 timestamp) → uint256 year, uint256 month, uint256 day internal`
