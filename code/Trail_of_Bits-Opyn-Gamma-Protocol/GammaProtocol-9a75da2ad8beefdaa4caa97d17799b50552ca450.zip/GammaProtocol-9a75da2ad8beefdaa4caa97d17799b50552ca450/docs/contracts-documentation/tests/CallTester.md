# `CallTester`

Call action testing contract

## Functions:

- `callFunction(address _sender, address _vaultOwner, uint256 _vaultId, bytes _data) (external)`

## Events:

- `CallFunction(address sender, address vaultOwner, uint256 vaultId, bytes data)`

### Function `callFunction(address _sender, address _vaultOwner, uint256 _vaultId, bytes _data) external`

### Event `CallFunction(address sender, address vaultOwner, uint256 vaultId, bytes data)`
