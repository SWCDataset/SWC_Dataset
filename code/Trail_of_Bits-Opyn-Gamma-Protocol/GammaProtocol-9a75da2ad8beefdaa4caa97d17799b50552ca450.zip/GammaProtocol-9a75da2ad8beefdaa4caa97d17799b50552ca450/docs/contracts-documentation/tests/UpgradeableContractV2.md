# `UpgradeableContractV2`

Upgradeable testing contract

## Functions:

- `getV2Version() (external)`

### Function `getV2Version() → uint256 external`
