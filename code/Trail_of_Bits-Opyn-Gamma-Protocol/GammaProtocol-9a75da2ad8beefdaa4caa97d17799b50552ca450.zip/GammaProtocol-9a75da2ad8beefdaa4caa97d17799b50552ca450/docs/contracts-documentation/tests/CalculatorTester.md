# `CalculatorTester`

## Functions:

- `constructor(address _addressBook) (public)`

- `getExpiredCashValue(address _otoken) (external)`

### Function `constructor(address _addressBook) public`

### Function `getExpiredCashValue(address _otoken) → uint256 external`
