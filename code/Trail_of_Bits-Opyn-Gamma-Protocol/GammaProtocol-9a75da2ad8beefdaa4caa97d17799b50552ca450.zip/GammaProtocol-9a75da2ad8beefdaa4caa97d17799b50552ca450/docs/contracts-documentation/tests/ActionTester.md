# `ActionTester`

## Functions:

- `testParseDespositAction(struct Actions.ActionArgs _args) (external)`

- `getDepositArgs() (external)`

- `testParseWithdrawAction(struct Actions.ActionArgs _args) (external)`

- `getWithdrawArgs() (external)`

- `testParseOpenVaultAction(struct Actions.ActionArgs _args) (external)`

- `getOpenVaultArgs() (external)`

- `testParseRedeemAction(struct Actions.ActionArgs _args) (external)`

- `getRedeemArgs() (external)`

- `testParseSettleVaultAction(struct Actions.ActionArgs _args) (external)`

- `getSettleVaultArgs() (external)`

- `testParseMintAction(struct Actions.ActionArgs _args) (external)`

- `getMintArgs() (external)`

- `testParseBurnAction(struct Actions.ActionArgs _args) (external)`

- `getBurnArgs() (external)`

- `testParseCallAction(struct Actions.ActionArgs _args) (external)`

- `getCallArgs() (external)`

### Function `testParseDespositAction(struct Actions.ActionArgs _args) external`

### Function `getDepositArgs() → struct Actions.DepositArgs external`

### Function `testParseWithdrawAction(struct Actions.ActionArgs _args) external`

### Function `getWithdrawArgs() → struct Actions.WithdrawArgs external`

### Function `testParseOpenVaultAction(struct Actions.ActionArgs _args) external`

### Function `getOpenVaultArgs() → struct Actions.OpenVaultArgs external`

### Function `testParseRedeemAction(struct Actions.ActionArgs _args) external`

### Function `getRedeemArgs() → struct Actions.RedeemArgs external`

### Function `testParseSettleVaultAction(struct Actions.ActionArgs _args) external`

### Function `getSettleVaultArgs() → struct Actions.SettleVaultArgs external`

### Function `testParseMintAction(struct Actions.ActionArgs _args) external`

### Function `getMintArgs() → struct Actions.MintArgs external`

### Function `testParseBurnAction(struct Actions.ActionArgs _args) external`

### Function `getBurnArgs() → struct Actions.BurnArgs external`

### Function `testParseCallAction(struct Actions.ActionArgs _args) external`

### Function `getCallArgs() → struct Actions.CallArgs external`
