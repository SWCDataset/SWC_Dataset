# `SignedConverterTester`

SignedConverter contract tester

## Functions:

- `testFromInt(int256 a) (external)`

- `testFromUint(uint256 a) (external)`

### Function `testFromInt(int256 a) → uint256 external`

### Function `testFromUint(uint256 a) → int256 external`
