# rlc-token
RLC Token for the iEx.ec project    
This is a truffle 3 repo

## To test  
Launch `testrpc` on another terminal    
Launch `truffle test`
