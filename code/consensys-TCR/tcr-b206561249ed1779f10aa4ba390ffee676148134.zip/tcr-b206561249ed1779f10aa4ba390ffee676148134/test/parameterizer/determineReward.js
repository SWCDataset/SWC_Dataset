/* eslint-env mocha */
/* global contract */

contract('Parameterizer', () => {
  describe('Function: determineReward', () => {
    it('should return the correct number of tokens to be granted to the winning entity in a challenge.');
  });
});

