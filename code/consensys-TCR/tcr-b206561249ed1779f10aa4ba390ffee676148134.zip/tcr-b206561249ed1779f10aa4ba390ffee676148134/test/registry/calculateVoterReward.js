/* eslint-env mocha */
/* global contract */

contract('Registry', () => {
  describe('Function: calculateVoterReward', () => {
    it('should return the correct value');
    it('should throw errors if given false arguments');
  });
});

