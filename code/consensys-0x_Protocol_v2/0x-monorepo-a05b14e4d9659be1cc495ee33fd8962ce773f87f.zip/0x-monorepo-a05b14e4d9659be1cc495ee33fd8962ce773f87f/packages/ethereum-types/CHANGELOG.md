<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.0.1 - _July 23, 2018_

    * Dependencies updated

## v1.0.0 - _July 20, 2018_

    * Add `TraceParams` interface for `debug_traceTransaction` parameters (#675)
    * Add `TransactionReceiptStatus` type (#812)

## v0.0.2 - _June 1, 2018_

    * Initial publish (#642)
