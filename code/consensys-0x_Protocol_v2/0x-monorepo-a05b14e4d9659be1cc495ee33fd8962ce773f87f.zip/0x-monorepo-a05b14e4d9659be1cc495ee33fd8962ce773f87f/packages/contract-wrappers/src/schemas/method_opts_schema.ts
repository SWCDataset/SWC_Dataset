export const methodOptsSchema = {
    id: '/MethodOpts',
    properties: {
        defaultBlock: { $ref: '/BlockParam' },
    },
    type: 'object',
};
