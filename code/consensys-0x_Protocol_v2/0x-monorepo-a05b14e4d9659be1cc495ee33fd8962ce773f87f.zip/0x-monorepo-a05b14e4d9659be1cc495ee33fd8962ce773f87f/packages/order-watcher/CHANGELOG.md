<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.0.0 - _July 23, 2018_

    * Dependencies updated

## v1.0.0-rc.1 - _July 20, 2018_

    * Add support for ERC721 event watching and Exchange V2 events (#887)

## v0.0.8 - _July 18, 2018_

    * Dependencies updated

## v0.0.7 - _July 9, 2018_

    * Switch out simple getLogs polling with ethereumjs-blockstream (#825)
    * Do not stop subscription if error is encountered (#825)
    * Fixed a bug that caused the incorrect block to be fetched via JSON-RPC within Blockstream (#875)
    * Remove stateLayer config from OrderWatcher. It now always operates on the latest block (#875)

## v0.0.6 - _June 19, 2018_

    * Dependencies updated

## v0.0.5 - _May 29, 2018_

    * Dependencies updated

## v0.0.4 - _May 29, 2018_

    * Dependencies updated

## v0.0.3 - _May 29, 2018_

    * Dependencies updated

## v0.0.2 - _May 22, 2018_

    * Dependencies updated

## v0.0.1 - _May 22, 2018_

    * Moved OrderWatcher out of 0x.js package (#579)
