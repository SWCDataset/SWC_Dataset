export { runV1MigrationsAsync } from './1.0.0/migration';
export { runV2MigrationsAsync } from './2.0.0/migration';
export { runV2TestnetMigrationsAsync } from './2.0.0-beta-testnet/migration';
