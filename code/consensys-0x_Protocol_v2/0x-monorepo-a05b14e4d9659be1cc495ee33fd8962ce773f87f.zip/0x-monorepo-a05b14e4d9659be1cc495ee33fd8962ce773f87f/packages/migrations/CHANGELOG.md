<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.0.1 - _July 23, 2018_

    * Dependencies updated

## v1.0.0 - _July 20, 2018_

    * Added migrations for 0x Protocol v2

## v0.0.10 - _July 18, 2018_

    * Dependencies updated

## v0.0.9 - _July 9, 2018_

    * Dependencies updated

## v0.0.8 - _June 19, 2018_

    * Dependencies updated

## v0.0.7 - _May 22, 2018_

    * Use AssetProxyOwner instead of MultiSigWalletWithTimeLockExceptRemoveAuthorizedAddress (#675)

## v0.0.6 - _May 22, 2018_

    * Dependencies updated

## v0.0.5 - _May 5, 2018_

    * Dependencies updated

## v0.0.4 - _May 4, 2018_

    * Dependencies updated

## v0.0.3 - _April 18, 2018_

    * Dependencies updated
