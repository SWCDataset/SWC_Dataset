<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.0.1 - _July 23, 2018_

    * Dependencies updated

## v1.0.0 - _July 20, 2018_

    * Fix git remote tag removal step & add an additional sanity assertion (#803)
    * Make PR numbers links on Github releases

## v0.2.2 - _July 9, 2018_

    * Dependencies updated

## v0.2.1 - _June 19, 2018_

    * Dependencies updated

## v0.2.0 - _June 15, 2018_

    * Add `prepublish_checks` script (#650)

## v0.1.20 - _May 22, 2018_

    * Dependencies updated

## v0.1.19 - _May 4, 2018_

    * Dependencies updated

## v0.1.18 - _April 18, 2018_

    * Dependencies updated

## v0.1.17 - _April 11, 2018_

    * Dependencies updated

## v0.1.16 - _April 2, 2018_

    * Dependencies updated

## v0.1.13 - _March 17, 2018_

    * Add postpublish utils
