<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.0.0 - _July 23, 2018_

    * Dependencies updated

## v1.0.0-rc.1 - _July 20, 2018_

    * Update schemas for V2 or 0x Protocol (#615)
    * Added CallData schema (#821)
    * Update CallData schema id to CallData (#894)

## v0.8.3 - _July 18, 2018_

    * Dependencies updated

## v0.8.2 - _July 9, 2018_

    * Dependencies updated

## v0.8.1 - _June 19, 2018_

    * Dependencies updated

## v0.8.0 - _May 22, 2018_

    * Update Order & SignedOrder schemas, remove ECSignature schema and add Hex schema as part of V2 upgrades (#615)

## v0.7.24 - _May 22, 2018_

    * Dependencies updated

## v0.7.23 - _May 5, 2018_

    * Dependencies updated

## v0.7.22 - _May 4, 2018_

    * Dependencies updated

## v0.7.21 - _April 18, 2018_

    * Dependencies updated

## v0.7.20 - _April 11, 2018_

    * Dependencies updated

## v0.7.19 - _April 2, 2018_

    * Dependencies updated

## v0.7.18 - _April 2, 2018_

    * Dependencies updated

## v0.7.13 - _February 8, 2018_

    *   Fix publishing issue where .npmignore was not properly excluding undesired content (#389)

## v0.7.0 - _December 19, 2017_

    * Rename `subscriptionOptsSchema` to `blockRangeSchema` (#272)

## v0.6.7 - _November 13, 2017_

    * Re-publish JSON-schema previously published under NPM package 0x-json-schemas
