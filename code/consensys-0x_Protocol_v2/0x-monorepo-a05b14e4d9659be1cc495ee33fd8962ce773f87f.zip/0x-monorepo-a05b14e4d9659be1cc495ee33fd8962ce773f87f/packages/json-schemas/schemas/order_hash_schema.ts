export const orderHashSchema = {
    id: '/OrderHashSchema',
    type: 'string',
    pattern: '^0x[0-9a-fA-F]{64}$',
};
