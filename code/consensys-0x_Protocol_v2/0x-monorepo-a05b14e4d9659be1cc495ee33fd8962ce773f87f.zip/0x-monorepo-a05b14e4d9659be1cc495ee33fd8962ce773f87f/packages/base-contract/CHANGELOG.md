<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.0.1 - _July 23, 2018_

    * Dependencies updated

## v1.0.0 - _July 20, 2018_

    * Dependencies updated

## v0.3.6 - _July 18, 2018_

    * Dependencies updated

## v0.3.5 - _July 9, 2018_

    * Dependencies updated

## v0.3.4 - _June 19, 2018_

    * Update EthersJs to fix the `value.toLowerCase()` is not a function bug caused by `ethers.js` breaking patch version https://github.com/ethers-io/ethers.js/issues/201

## v0.3.3 - _June 1, 2018_

    * Incorrect publish that was unpublished

## v0.3.2 - _May 22, 2018_

    * Dependencies updated

## v0.3.1 - _May 5, 2018_

    * Dependencies updated

## v0.3.0 - _May 4, 2018_

    * Update ethers-contracts to ethers.js (#540)

## v0.2.1 - _April 18, 2018_

    * Dependencies updated

## v0.2.0 - _April 11, 2018_

    * Contract wrappers now accept Provider and defaults instead of Web3Wrapper (#501)

## v0.1.0 - _April 2, 2018_

    * Add tests for traversing ABI tree (#485)
    * Fix ABI tuples traversing (#485)
    * Fix ABI arrays traversing (#485)

## v0.0.6 - _April 2, 2018_

    * Dependencies updated

## v0.0.2 - _March 3, 2018_

    * Initial release
