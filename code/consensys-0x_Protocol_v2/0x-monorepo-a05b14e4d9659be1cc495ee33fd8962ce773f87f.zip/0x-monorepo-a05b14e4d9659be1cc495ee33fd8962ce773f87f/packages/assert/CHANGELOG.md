<!--
changelogUtils.file is auto-generated using the monorepo-scripts package. Don't edit directly.
Edit the package's CHANGELOG.json file only.
-->

CHANGELOG

## v1.0.1 - _July 23, 2018_

    * Dependencies updated

## v1.0.0 - _July 20, 2018_

    * Fix bug in string enum assertion. We erroneously were checking against the enum keys, not values (#821)

## v0.2.14 - _July 18, 2018_

    * Dependencies updated

## v0.2.13 - _July 9, 2018_

    * Dependencies updated

## v0.2.12 - _June 19, 2018_

    * Dependencies updated

## v0.2.11 - _June 1, 2018_

    * Incorrect publish that was unpublished

## v0.2.10 - _May 22, 2018_

    * Dependencies updated

## v0.2.9 - _May 5, 2018_

    * Dependencies updated

## v0.2.8 - _May 4, 2018_

    * Dependencies updated

## v0.2.7 - _April 18, 2018_

    * Dependencies updated

## v0.2.6 - _April 11, 2018_

    * Dependencies updated

## v0.2.5 - _April 2, 2018_

    * Dependencies updated

## v0.2.4 - _April 2, 2018_

    * Dependencies updated

## v0.2.0 - _March 7, 2018_

    * Rename `isHttpUrl` to `isWebUri` (#412)

## v0.1.0 - _March 3, 2018_

    * Remove isETHAddressHex checksum address check and assume address will be lowercased  (#373)
    * Add an optional parameter `subSchemas` to `doesConformToSchema` method (#385)

## v0.0.18 - _February 8, 2017_

    * Fix publishing issue where .npmignore was not properly excluding undesired content (#389)

## v0.0.4 - _November 13, 2017_

    * Re-publish Assert previously published under NPM package @0xproject/0x-assert
    * Added assertion isValidBaseUnitAmount which checks both that the value is a valid bigNumber and that it does not contain decimals.
