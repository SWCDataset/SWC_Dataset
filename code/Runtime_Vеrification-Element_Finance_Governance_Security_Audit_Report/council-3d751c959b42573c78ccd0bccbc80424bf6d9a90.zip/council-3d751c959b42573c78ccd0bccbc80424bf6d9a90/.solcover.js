module.exports = {
    skipFiles: ["balancer-core-v2/lib/helpers/BalancerErrors.sol"]
  };
