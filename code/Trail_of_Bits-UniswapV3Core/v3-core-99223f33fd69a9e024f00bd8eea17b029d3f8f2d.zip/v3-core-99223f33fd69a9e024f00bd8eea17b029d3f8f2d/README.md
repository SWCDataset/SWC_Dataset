# ⚠️ STRICTLY CONFIDENTIAL RESEARCH ⚠️

# Uniswap V3

[![Tests](https://github.com/Uniswap/uniswap-v3-core/workflows/Tests/badge.svg)](https://github.com/Uniswap/uniswap-v3-core/actions?query=workflow%3ATests)
[![Fuzz Testing](https://github.com/Uniswap/uniswap-v3-core/workflows/Fuzz%20Testing/badge.svg)](https://github.com/Uniswap/uniswap-v3-core/actions?query=workflow%3A%22Fuzz+Testing%22)
[![Lint](https://github.com/Uniswap/uniswap-v3-core/workflows/Lint/badge.svg)](https://github.com/Uniswap/uniswap-v3-core/actions?query=workflow%3ALint)
