## veMULTI 

Vote escrow MULTI based on solidly [ve.sol](https://github.com/solidlyexchange/solidly/blob/master/contracts/ve.sol)

## testnet
BSC testnet
- Multi: 0x74e8e6eb31ef6970d2623a1c700cbe6f56f20f43
- veMULTI: 0x27C03bDc9ec0945a4ab06DDC11CC0e8946eC4Aab
- Reward token: 0xB608035D8555ba924EceBb6239b148f99224A36C
- Reward: 0x25c5Cc9082d7d87B3321868bA2C64e0C969072a4

