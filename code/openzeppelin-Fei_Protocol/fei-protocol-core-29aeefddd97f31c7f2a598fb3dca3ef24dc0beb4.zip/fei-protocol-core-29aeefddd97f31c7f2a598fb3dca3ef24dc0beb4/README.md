# [Fei Protocol](http://fei.money/) &middot; [![License: AGPL v3](https://img.shields.io/badge/License-AGPL%20v3-blue.svg)](https://www.gnu.org/licenses/agpl-3.0)
Smart contract code for Fei Protocol and the FEI stablecoin

## Documentation
See the [Wiki](https://github.com/fei-protocol/fei-protocol-core/wiki)

## License
Fei Protocol is under [the AGPL v3 license](LICENSE.md)
